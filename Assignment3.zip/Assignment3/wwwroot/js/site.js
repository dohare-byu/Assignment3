﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


/*$("#submitButton").click(function () {
    var category = $("#category").val()
    var title = $("#title").val()
    var year = $("#year").val()
    var director = $("#director").val()
    var rating = $("#rating").val()
    var edited = $("#edited").val()
    var lent = $("#lent").val()
    var notes = $("#notes").val()

    alert('Success!' + title);
    //window.location = asp - controller="Home" asp - action="newMovie"
})
*/